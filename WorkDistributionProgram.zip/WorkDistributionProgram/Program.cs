﻿using System.Reflection;
using static System.Net.Mime.MediaTypeNames;

namespace WorkDistributionProgram
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string filePath = "data.csv";
            string folder = Directory.GetCurrentDirectory();
            Console.WriteLine(Path.Combine(folder,filePath));
            // Check if the file exists
            if (!File.Exists(filePath))
            {
                Console.WriteLine("File not found.");
                return;
            }
            try
            {
                // Read all lines from the file
                string[] lines = File.ReadAllLines(filePath);

                // Extract the number of staff members
                if (lines.Length < 2)
                {
                    Console.WriteLine("Invalid file format. Expected at least 2 lines.");
                    return;
                }

                if (!int.TryParse(lines[0], out int numStaff))
                {
                    Console.WriteLine("Invalid number of staff members.");
                    return;
                }

                // Read the workload values
                string[] workloadStr = lines[1].Split(',');

                // Validate input format
                if (workloadStr.Length != numStaff)
                {
                    Console.WriteLine("Invalid input format. Expected workload values for each staff member.");
                    return;
                }

                decimal[] workload = new decimal[numStaff];
                for (int i = 0; i < numStaff; i++)
                {
                    // Validate workload values
                    if (!decimal.TryParse(workloadStr[i], out workload[i]) || workload[i] < 0)
                    {
                        Console.WriteLine($"Invalid workload value for staff {i + 1}.");
                        return;
                    }
                    
                }
                // Calculate total workload
                decimal totalWorkload = workload.Sum();

                // Calculate target workload per staff member
                decimal targetWorkload = totalWorkload / numStaff;

                // Distribute workload
                decimal[] assignedWorkload = new decimal[numStaff];
                for (int i = 0; i < numStaff; i++)
                {
                    assignedWorkload[i] = Math.Min(workload[i], targetWorkload);
                    workload[i] -= assignedWorkload[i];
                }

                // Reassign remaining workload
                for (int i = 0; i < numStaff; i++)
                {
                    if (workload[i] > 0)
                    {
                        for (int j = 0; j < numStaff; j++)
                        {
                            if (j == i) continue;

                            // Check if workload can be assigned to the perticular staff
                            if (assignedWorkload[j] < targetWorkload)
                            {
                                decimal capability = targetWorkload - assignedWorkload[j];
                                decimal canBeAssigned = Math.Min(workload[i], capability);
                                assignedWorkload[j] +=canBeAssigned;
                                workload[i] -= canBeAssigned;
                            }                            
                        }
                    }
                }

                // Output the sum of work assigned to each staff member
                for (int i = 0; i < numStaff; i++)
                {
                    Console.WriteLine($"Total Work Assigned to Staff {i + 1}: {assignedWorkload[i]}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
        }









































        //    // Check if a file path is provided as argument
        //    if (args.Length == 0)
        //    {
        //        Console.WriteLine("Please provide the path to the CSV file as an argument.");
        //        return;
        //    }

        //    string filePath = ;
        //    Console.WriteLine(filePath);
        //    // Check if the file exists
        //    if (!File.Exists(filePath))
        //    {
        //        Console.WriteLine("File not found.");
        //        return;
        //    }

        //    try
        //    {
        //        // Read all lines from the file
        //        string[] lines = File.ReadAllLines(filePath);

        //        // Extract the number of staff members
        //        if (lines.Length < 2)
        //        {
        //            Console.WriteLine("Invalid file format. Expected at least 2 lines.");
        //            return;
        //        }

        //        if (!int.TryParse(lines[0], out int numStaff))
        //        {
        //            Console.WriteLine("Invalid number of staff members.");
        //            return;
        //        }

        //        // Extract the workload values
        //        string[] workloadStr = lines[1].Split(',');
        //        if (workloadStr.Length != numStaff)
        //        {
        //            Console.WriteLine("Number of workload values doesn't match the number of staff members.");
        //            return;
        //        }

        //        // Parse workload values into decimal
        //        decimal[] workload = new decimal[numStaff];
        //        for (int i = 0; i < numStaff; i++)
        //        {
        //            if (!decimal.TryParse(workloadStr[i], out workload[i]))
        //            {
        //                Console.WriteLine($"Invalid workload value at index {i}.");
        //                return;
        //            }
        //        }

        //        // Calculate the total workload
        //        decimal totalWorkload = workload.Sum();

        //        // Calculate the workload per staff member
        //        decimal workloadPerStaff = totalWorkload / numStaff;

        //        // Output the sum of work assigned to each staff member
        //        for (int i = 0; i < numStaff; i++)
        //        {
        //            Console.WriteLine($"Total Work Assigned to Staff {i + 1}: {workloadPerStaff}");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine($"An error occurred: {ex.Message}");
        //    }
        //}
    }
}