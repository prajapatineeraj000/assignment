﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleCRUDWinForm
{
    public partial class Form1 : Form
    {
        private const string connectionString = "Data Source=.;Initial Catalog=Crud_Db;Integrated Security=True;";
        private SqlConnection connection;
        public Form1()
        {
            InitializeComponent();
            connection = new SqlConnection(connectionString);
        }

        private void Create_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;
            int age;
            if (!int.TryParse(txtAge.Text, out age))
            {
                MessageBox.Show("Age must be a valid number.");
                return;
            }

            try
            {
                connection.Open();
                string query = "INSERT INTO Person (Name, Age) VALUES (@Name, @Age)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Name", name);
                command.Parameters.AddWithValue("@Age", age);
                int rowsAffected = command.ExecuteNonQuery();
                lblMsg.Text = rowsAffected + " row(s) inserted successfully.";
                lblMsg.Visible = true;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        private void Read_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;
            int age;

            if (!int.TryParse(txtAge.Text, out age))
            {
                MessageBox.Show("Age must be a valid number.");
                return;
            }

            try
            {
                connection.Open();
                string query = "SELECT COUNT(*) FROM Person WHERE Name = @Name AND Age = @Age";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Name", name);
                command.Parameters.AddWithValue("@Age", age);
                int count = (int)command.ExecuteScalar();
                if (count > 0)
                {
                    lblMsg.Text = "Data exists in the database.";
                    lblMsg.Visible = true;
                }                    
                else
                    lblMsg.Text = "Data does not exist in the database.";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        private void Update_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;
            int age;

            if (!int.TryParse(txtAge.Text, out age))
            {
                MessageBox.Show("Age must be a valid number.");
                return;
            }

            try
            {
                connection.Open();
                string query = "UPDATE Person SET Age = @Age WHERE Name = @Name";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Name", name);
                command.Parameters.AddWithValue("@Age", age);
                int rowsAffected = command.ExecuteNonQuery();
                lblMsg.Text = rowsAffected + " row(s) updated successfully.";
                lblMsg.Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;
            int age;

            if (!int.TryParse(txtAge.Text, out age))
            {
                MessageBox.Show("Age must be a valid number.");
                return;
            }

            try
            {
                connection.Open();
                string query = "DELETE FROM Person WHERE Name = @Name AND Age = @Age";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Name", name);
                command.Parameters.AddWithValue("@Age", age);
                int rowsAffected = command.ExecuteNonQuery();
                lblMsg.Text = rowsAffected + " row(s) deleted successfully.";
                lblMsg.Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
